﻿
//  Author: PHNO - Technologist | Postgraduate in Photovoltaic Solar Energy
//  Release Date: 18/10/2024
//  Version: 0.0.0.2v
//  Replit: @PHNO, @PHREPLIT
//  E-mail: phreplit@gmail.com

// Software: $safeprojectname$ - 0.0.0.2v - Measurement and Calculation for Residential Roof, with GUI [graphical interface] and compilation in desktop environment.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int var1) && int.TryParse(textBox2.Text, out int var2))
            {
                int mult = var1 * var2;

                textBox3.Text = ("" + mult);
            }
            else
            {
                textBox3.Text = "Error. enter required field.";
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int var1) && int.TryParse(textBox2.Text, out int var2))
            {
                this.Text = "$safeprojectname$ - 0.0.0.2v - Measurement and Calculation for Residential Roof";
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear(); // call clear method
            }
            else
            {
                textBox3.Text = "Error. nothing to clear.";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox4.Text, out int var3) && int.TryParse(textBox5.Text, out int var4) && int.TryParse(textBox6.Text, out int var5) && int.TryParse(textBox7.Text, out int var6))
            {
                int vartwo = 2;
                int mult2 = var3 + var4;
                int mult3 = mult2 / vartwo;
                int mult4 = var5 + var6;
                int mult5 = mult4 / vartwo;
                int result = mult3 * mult5;

                textBox8.Text = ("" + result);
            }
            else
            {
                textBox8.Text = "Error. enter required field.";
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox4.Text, out int var3) && int.TryParse(textBox5.Text, out int var4))
            {
                this.Text = "$safeprojectname$ - 0.0.0.2v - Measurement and Calculation for Residential Roof";
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear(); // call clear method
                textBox7.Clear();
                textBox8.Clear();
            }
            else
            {
                textBox8.Text = "Error. nothing to clear.";
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox9.Text, out int var8) && int.TryParse(textBox10.Text, out int var9))
            {
                this.Text = "$safeprojectname$ - 0.0.0.2v - Measurement and Calculation for Residential Roof";
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear(); // call clear method
            }
            else
            {
                textBox11.Text = "Error. nothing to clear.";
            }

        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox9.Text, out int var10) && int.TryParse(textBox10.Text, out int var11))
            {
                int mult4 = var10 + var11;

                textBox11.Text = ("" + mult4);
            }
            else
            {
                textBox11.Text = "Error. enter required field.";
            }

        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox9.Text, out int var10) && int.TryParse(textBox10.Text, out int var11))
            {
                int mult5 = var10 - var11;

                textBox11.Text = ("" + mult5);
            }
            else
            {
                textBox11.Text = "Error. enter required field.";
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox9.Text, out int var10) && int.TryParse(textBox10.Text, out int var11))
            {
                int mult6 = var10 / var11;

                textBox11.Text = ("" + mult6);
            }
            else
            {
                textBox11.Text = "Error. enter required field.";
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox9.Text, out int var10) && int.TryParse(textBox10.Text, out int var11))
            {
                int mult7 = var10 * var11;

                textBox11.Text = ("" + mult7);
            }
            else
            {
                textBox11.Text = "Error. enter required field.";
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox12.Text, out int var13) && int.TryParse(textBox13.Text, out int var14))
            {
                int mult8 = var13 * var14;

                textBox14.Text = ("" + mult8);
            }
            else
            {
                textBox14.Text = "Error. enter required field.";
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox12.Text, out int var8) && int.TryParse(textBox13.Text, out int var9))
            {
                this.Text = "$safeprojectname$ - 0.0.0.2v - Measurement and Calculation for Residential Roof";
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear(); // call clear method
            }
            else
            {
                textBox14.Text = "Error. nothing to clear.";
            }

        }

        private void button12_Click(object sender, EventArgs e)
        {
            this.Text = "Info";
            // classe, metodo, string(texto)
            MessageBox.Show("Info\n"
                + "\nTo calculate the square meter of the roof with 4 equal sides [equal footage] we calculate Length x Width."
                + "\nTo calculate the square meter with 4 different sides [different footage] we add the two parallel sides, "
                + "\nwe add the length to the length and divide it by 2, thus taking the average, "
                + "\nwe do the same with the width, we add the width to the width and divide by 2 taking the average, "
                + "\nand with the results of the average of the parallel sides (width and length) "
                + "\nwe multiply the two parallel sides Length x Width and thus we obtain the square meters of a roof with 4 different sides.\n"
                + "\nTo calculate the Quantity of Tiles per Square Meter: \n"
                + "\nTaking as an example an American tile with dimensions (43Lx26W) in centimeters in horizontal axis view, "
                + "\nand knowing that calculating a square meter of a roof will be L x W then 1 Square Meter = 12 tiles, "
                + "\nso one square meter has 12 tiles so this will be the standard measurement. 12 x so many square meters = the amount of tiles per square meter.\n"
                + "\nTo calculate the Colonial Tile: 1 M² = 16 tiles."
                + "\nTo calculate the Italian Tile: 1 M² = 14 tiles."
                + "\nTo calculate the Portuguese Tile: 1 M² = 17 tiles.\n"
                + "\nTo calculate the Roman Tile: \n"
                + "\nTaking as an example a Roman tile with dimensions (40Lx21W) in centimeters in horizontal axis view, "
                + "\nand knowing that calculating a square meter of a roof will be L x W then 1 Square Meter = 16 tiles,"
                + "\n so one square meter has 16 tiles so this will be the standard measurement. 16 x so many square meters = the number of tiles per square meter.\n"
                + "\nImportant Information: \n"
                + "\nNote: This software was developed with integer variables, so it does not allow the insertion of numbers and commas. (ex: 2.90 meters change to 3 meters)."
                + "\nNote: The calculation of the square meter of a residential roof in this software is done without calculating the slope. "
                + "\nIf the calculation of the square meter is done with the slope, with the increase in the degree of inclination of the roof,"
                + "\nThere will be an increase in the amount of tiles needed to tile and build a residential roof."
                + "\nNote: the installation, construction and dimensioning of a residential roof requires a qualified and trained professional, such as a civil engineer. \n"
                + "\nTile Pattern per Square Meter and Quantity of Tiles: \n"
                + "\n The number of tiles can vary for more tiles or fewer tiles, depending on the dimensions of the chosen tile, "
                + "\nso see that in the case of installing colonial tiles, the arrangement (fitting) of the tiles will be done with two layers of tiles, "
                + "\nwhich can lead to variations (more or less) in the number of tiles needed to cover one square meter."
                + "\n There is therefore a possible difference in the pattern and quantity of tiles per square meter for colonial tiles as described above.\n"
                + "\nTile Model per Square Meter and Quantity of Tiles: \n"
                + "\nIf you want to calculate a new tile model that is not in the conversion table, you will need to know the dimensions of the new tile model and know how many tiles will be needed to cover one square meter, so it will be (N) tiles per 1M².");
        }

        private void button13_Click(object sender, EventArgs e)
        {
            this.Text = "About";
            MessageBox.Show("About\n" + "\nSoftware: $safeprojectname$ - Measurement and Calculation for Residential Roof \n" + "\nAuthor: PHNO" + "\nRelease Date: 18/10/2024" + "\nVersion: 0.0.0.2v" + "\nReplit: @PHNO, @PHREPLIT" + "\nE-mail: phreplit@gmail.com");
        }

        private void button14_Click(object sender, EventArgs e)
        {
            this.Text = "$safeprojectname$ - 0.0.0.2v - Measurement and Calculation for Residential Roof";
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear(); // call clear method
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();
            textBox10.Clear();
            textBox11.Clear();
            textBox12.Clear();
            textBox13.Clear();
            textBox14.Clear();
        }
    }
}
